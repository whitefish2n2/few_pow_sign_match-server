package uk.fishgames.fpsserver_outgame.matching.dto

enum class MapEnum {
    Test,
    Haven,
}