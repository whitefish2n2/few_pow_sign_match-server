package uk.fishgames.fpsserver_outgame.matching.dto

enum class SessionAttributesEnum(val value: String) {
    userId("userId"),
    userKey("userKey")
}