package uk.fishgames.fpsserver_outgame.matching


class MatchRestTemplate {
}