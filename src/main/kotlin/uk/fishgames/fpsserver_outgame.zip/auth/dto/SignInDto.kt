package uk.fishgames.fpsserver_outgame.auth.dto


data class SignInDto(
    val id: String,
    val password: String,
)