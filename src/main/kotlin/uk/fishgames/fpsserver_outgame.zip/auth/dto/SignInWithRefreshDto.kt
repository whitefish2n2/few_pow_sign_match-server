package uk.fishgames.fpsserver_outgame.auth.dto;

data class SignInWithRefreshDto (
    val refreshToken: String,
)
