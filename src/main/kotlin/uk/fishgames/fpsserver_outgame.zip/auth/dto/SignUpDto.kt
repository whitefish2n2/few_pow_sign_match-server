package uk.fishgames.fpsserver_outgame.auth.dto

data class SignUpDto (
    val id:String,
    val password:String,
    val name:String,
)