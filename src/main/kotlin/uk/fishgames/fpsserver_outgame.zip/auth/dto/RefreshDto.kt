package uk.fishgames.fpsserver_outgame.auth.dto

class RefreshDto {
    val jwt: String = ""
    val refreshToken: String = ""
}