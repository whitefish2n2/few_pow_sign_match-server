package uk.fishgames.fpsserver_outgame.dedicate_server

import uk.fishgames.fpsserver_outgame.matching.dto.Player
import uk.fishgames.fpsserver_outgame.matching.dto.TryCharacterPickDto
import java.time.LocalDateTime

class Session(val gameId:String, val runningOn:Dedicated) {
    var status: SessionStatus = SessionStatus.Idle
    val playerLists: HashMap<String, Player> = HashMap<String, Player>();//String:User SessionKey
    var score:String = "0:0"
    var playTime:LocalDateTime = LocalDateTime.now()
    fun Init(){
        status = SessionStatus.Idle
        for(p in playerLists.values){
            p.matchWebsocket?.close();
        }
        playerLists.clear()
        score = ""
        playTime = LocalDateTime.now()
    }
    fun pickCharacter(dto: TryCharacterPickDto){
        //todo 만드는ㄴ중
    }
}
enum class SessionStatus{
    Playing,
    Idle
}